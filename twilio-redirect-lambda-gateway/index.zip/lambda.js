'use strict';

exports.handler = async (req, context, res) => {
console.log(req.Caller);
	var responseBody =  `<?xml version="1.0" encoding="UTF-8"?><Response><Say voice="alice" language="en-GB">Thank you for calling Re-com-bix Limited.</Say><Dial callerId="${req.Caller}">+447506659150</Dial><Hangup/></Response>`;

res(null, responseBody);

};
