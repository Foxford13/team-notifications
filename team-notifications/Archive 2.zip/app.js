'use strict';






// exports.handler = function(event, context, callback) {



	const express = require('express');
	const app = express();
	const https = require(`https`);
	const SERVER = require('./config/server.json');
	const bodyParser = require('body-parser');
	const cors = require('cors');
	const awsServerlessExpressMiddleware = require('aws-serverless-express/middleware');

	app.use(bodyParser.urlencoded({  // This will let us get the data from a POST.
		extended: true,
	}));
	app.use(bodyParser.json());

app.use(awsServerlessExpressMiddleware.eventContext());

// Configure the app port
const port = process.env.PORT || SERVER.port;
app.set('port', port);



// Start the server and listen on the preconfigured port
// app.listen(port, () => console.log(`App started on port ${port}.`));


app.get('/', (req, res, next) => {
	res.send(``);
});

// +441296327565

// Telephony script.
app.post(`/telephony`, (req, res) => {

	res.setHeader(`Content-Type`, `text/xml`);

	console.log(req.body['From']);
	res.end([
		`<?xml version="1.0" encoding="UTF-8"?>`,
		`<Response>`,
		`<Say voice="alice" language="en-GB">Thank you for calling Re-com-bix Limited.</Say>`,
		`<Dial callerId="${req.body['Called']}">+447506659150</Dial>`,
		`<Hangup/>`,
		`</Response>`,
	].join(``));

});

// CAU9F7PDL



// xoxp-241039502672-249883938884-367634864005-527ac69d8b33d53ea8ac0c496ac085d6



/*
* Send a POST request to the Slack webhook URI.
*/
async function pushToSlack (webhookUri, delType, content, attachedImgUrl) {

	// const from = content.from;
	// const to = content.to;
	// const comment = content.comment;

	// Skip if there is no webhook URI.

	if (!webhookUri) { return; }


	return await new Promise((resolve, reject) => {

		const uri = new URL(webhookUri);

		const postData = JSON.stringify({
			text: content,


			    text: content,
			    attachments: [
			        {
			            fallback: "Required plain-text summary of the attachment.",
			            title: "Awesome",
			            title_link: "https://media.welkio.com/images/visitors/t-avatar-md/7ff7408dd66649c08bfc723770de0e0c41fedb07e40941ac84d55c6d98beaf57.png",
			            text: "Optional text that appears within the attachment",
			            image_url: "https://media.welkio.com/images/visitors/t-avatar-md/7ff7408dd66649c08bfc723770de0e0c41fedb07e40941ac84d55c6d98beaf57.png"
			        }
			    ]


		});

		const req = https.request({
			protocol: uri.protocol,
			hostname: uri.hostname,
			port: 443,
			method: `POST`,
			path: uri.pathname,
		}, res => {

			const resData = [];

			res.setEncoding(`utf8`);

			// Are we redirecting?
			if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
				const redirectPromise = pushToSlack(res.headers.location);
				return resolve(redirectPromise);
			}

			// Otherwise get the response payload.
			res.on(`data`, chunk => resData.push(chunk));
			res.on(`end`, () => {
				const result = resData.join(``);
				if (result !== `ok`) { return reject(new Error(`Expected Slack response to be "ok" but got "${result}".`)); }
				return resolve();
			});
			res.on(`error`, err => reject(err));

		});

		req.end(postData);

	});

}

const testingUrl = `Received: from MMXP123MB1087.GBRP123.PROD.OUTLOOK.COM (2603:10a6:a00:15::18)
 by LOXP123MB1077.GBRP123.PROD.OUTLOOK.COM with HTTPS via
 MMXP123CA0011.GBRP123.PROD.OUTLOOK.COM; Tue, 22 May 2018 16:43:20 +0000
Received: from MMXP123CA0035.GBRP123.PROD.OUTLOOK.COM (2603:10a6:a00:15::42)
 by MMXP123MB1087.GBRP123.PROD.OUTLOOK.COM (2603:10a6:a00:20::9) with
 Microsoft SMTP Server (version=TLS1_2,
 cipher=TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P256) id 15.20.776.11; Tue, 22
 May 2018 16:43:19 +0000
Received: from LO2GBR01FT011.eop-gbr01.prod.protection.outlook.com
 (2a01:111:f400:7e15::208) by MMXP123CA0035.outlook.office365.com
 (2603:10a6:a00:15::42) with Microsoft SMTP Server (version=TLS1_2,
 cipher=TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384) id 15.20.776.11 via Frontend
 Transport; Tue, 22 May 2018 16:43:19 +0000
Authentication-Results: spf=pass (sender IP is 50.31.156.124)
 smtp.mailfrom=postmark-mail.wework.com; recombix.com; dkim=pass (signature
 was verified) header.d=pm.mtasv.net;recombix.com; dmarc=pass action=none
 header.from=wework.com;
Received-SPF: Pass (protection.outlook.com: domain of postmark-mail.wework.com
 designates 50.31.156.124 as permitted sender)
 receiver=protection.outlook.com; client-ip=50.31.156.124;
 helo=sc-ord-mta124.mtasv.net;
Received: from sc-ord-mta124.mtasv.net (50.31.156.124) by
 LO2GBR01FT011.mail.protection.outlook.com (10.152.42.97) with Microsoft SMTP
 Server (version=TLS1_2, cipher=TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P256) id
 15.20.776.10 via Frontend Transport; Tue, 22 May 2018 16:43:17 +0000
DKIM-Signature: v=1; a=rsa-sha1; c=relaxed/relaxed; s=pm; d=pm.mtasv.net;
 h=Message-ID:MIME-Version:From:To:Date:Subject:Content-Type;
 bh=XOC36uik/nEp/MUpRD4AZRK05UQ=;
 b=qdx7I0LKcFk0i7j4XpxhI9bN6FFJ6AQi/drrK5gxYDYSkKA7DDpEecly0mvFJcIfc172CP2E1/yL
   uTYOf++KcbEHhRvyiki6TnAQ7r89arjDkYbGd8Byd0j82/wX6CdOeQyGaMoLZ9xGTKfF+mgeB964
   t7IioR3neSCF2+MouUQ=
Received: by sc-ord-mta124.mtasv.net id h0h4aa1jk5kj for <jakub@recombix.com>; Tue, 22 May 2018 12:43:16 -0400 (envelope-from <pm_bounces@postmark-mail.wework.com>)
X-PM-IP: 50.31.156.124
X-IADB-IP: 50.31.156.124
X-IADB-IP-REVERSE: 124.156.31.50
Message-ID: <26e2077410b46400a44ff9213d5892ff@swift.generated>
X-PM-KeepID: true
Feedback-ID: s2344181-_:s2344181:a121752:postmark
X-Complaints-To: abuse@postmarkapp.com
X-PM-Message-Id: d31fef33-8b07-42d6-9071-dc07e01fd4c9
X-PM-RCPT: |bTB8MTIxNzUyfDIzNDQxODF8amFrdWJAcmVjb21iaXguY29t|
MIME-Version: 1.0
From: "WeWork Moorgate" <moorgate@wework.com>
To: "Jakub Dziekan" <jakub@recombix.com>
Date: 22 May 2018 12:43:16 -0400
Subject: Front Desk Guest: Gggg Gghhg
Return-Path: pm_bounces@postmark-mail.wework.com
X-MS-Exchange-Organization-ExpirationStartTime: 22 May 2018 16:43:17.8070
 (UTC)
X-MS-Exchange-Organization-ExpirationStartTimeReason: Original Submit
X-MS-Exchange-Organization-ExpirationInterval: 2:00:00:00.0000000
X-MS-Exchange-Organization-ExpirationIntervalReason: Original Submit
X-MS-Exchange-Organization-Network-Message-Id: 48a72bd9-2e36-4726-a581-08d5c0031edd
X-EOPAttributedMessage: 0
X-EOPTenantAttributedMessage: f9cd9cab-0fbe-499e-afa8-70c6c5d6219f:0
X-MS-Exchange-Organization-MessageDirectionality: Incoming
X-Forefront-Antispam-Report: CIP:50.31.156.124;IPV:NLI;CTRY:US;EFV:NLI;SFV:NSPM;SFS:(8046002)(31600200002)(2980300002)(438002)(286005)(189003)(199004)(7636002)(2160300002)(6986002)(110466001)(106466001)(564344004)(980100002)(104016004)(7596002)(120006004)(95666005)(606006)(5000100001)(6916009)(4290100001)(15003)(236005)(6306002)(9686003)(33896004)(33964004)(246002)(108616005)(24736004)(26005)(1096003)(126002)(476003)(620700001)(16586007)(106002)(336012)(486006)(356003)(42186006)(84326002)(8676002)(733005)(92100200004);DIR:INB;SFP:;SCL:1;SRVR:MMXP123MB1087;H:sc-ord-mta124.mtasv.net;FPR:;SPF:Pass;LANG:en;PTR:sc-ord-mta124.mtasv.net;MX:1;A:1;
X-Microsoft-Exchange-Diagnostics: 1;LO2GBR01FT011;1:qgmxwq9Bwk8SVGPys/OUqmlrndwfdabnMnwhyqfJ/tJMk7u8tecd7TWVTXhHj0ZGe1xprOU+Tk1FXADRU/e1ct977euawiaiSZedX3hMVyZu+0gRoHVJVnQF9NceVLH7
X-MS-Exchange-Organization-AuthSource: LO2GBR01FT011.eop-gbr01.prod.protection.outlook.com
X-MS-Exchange-Organization-AuthAs: Anonymous
X-MS-PublicTrafficType: Email
X-Microsoft-Antispam: UriScan:;BCL:4;PCL:0;RULEID:(7020095)(5600026)(4605076)(4608076)(1401150)(8001031)(1402068)(71702078);SRVR:MMXP123MB1087;
X-Microsoft-Exchange-Diagnostics: 1;MMXP123MB1087;3:8wd3AO3PN96EMfYdsYtoHeyoH38nDNm66yOmjRWYIhzXIho85ZvTLa97hbZVTNImnEDWacQVump+B5ZL+3U12eXqHHbyP7JyXyA0z3V+9rd10CJPdkZHjGiiQrTPweSRlEzXHrUOABbsUaGx9IFZlhEciF9Fu/7jVDvIbgCYORaHcV1B7Xq71XENw4xUzGHUXW3r1ggsp3r8i/QuniA92qVzfSvbK+L3Q/wzKeH1ezfJcrW2pqjnMhBpEqDJe70who5mjNblmt8xmldI6hQ+0JveWXswMM0y85tNfubNQsR5PjjiQbe9iEW94TV6YgBWW/j/XuDa5NxMJNCRh45Ni8/0dyszBjNeo5oHB8CrcwA=;25:vpWj7Ihm3nXkHAsH7O+GjXifMhgf+egYkWRiS7SvLmY8CEyIMzwF3xt1mIkWTmPMCPMhSR2N1gbuUi8rZaO4xfGqOeX3hSjOXTjEWc2e8Bh5nj77RpDBmSFAt+AQ+OMexa3J14M3yI1fJB7Fh+lLmkoY+AY0Bt3REjve5WHhx6Przq8UVQV2djrXz7ZJ0RwdLOsAZS3fAwtnFi83d3Boe+D0+CsCyn4Q4SSthUwFDOfT0F5kdnKQzOHPH2Q20yGeVEDK+tfD9+OviEZl1Mu8HQYHguyf8aNEQxNKtAm6YSNl1l5ebS+kY+lZAmSrbfS+vFwmjRBAuaLqwuKQ1looXg==
X-MS-TrafficTypeDiagnostic: MMXP123MB1087:
X-Microsoft-Exchange-Diagnostics: 1;MMXP123MB1087;31:4n/rW4oFOC8drD2PqdaQrjyKj5fkaNmc+LqtMvJXg+Z8WUqKEF8PAqw4J8uYctqAEijYxwKjqwolBeM2RClSKsDm12V6bNucVyMEQuR8NrAkMp09XL4ijdKAi2c3m9jTutP+e0oI2bb2WTbRgsz37AWOYOYUOd58hNNltz2S/cybYK8hQaRYHR1J61J7U70wDG4WmysGHtZi0Np8famVVcC3mk3L+iC862qs5Xg7X6Y=;20:DLYvj0ZgT6BeqzInrO+xF3/MbGn3guVhiqtmADRp1TeI4TOwrU84EMF3NaQf4QFGq+tNA7hbnmkBa7lx/tUopWoUvfZM0LTNEjQGTxSn9DYuLPDlXmT1nUa0TpI/3lkTfrom1wuCYlWGSb4Pk5+3ynxp36PPt280ejtpYdOQ98E=;4:3vQk9zuoX4pew9N/6ZHOE+p8r1/QOvPZdKrRRPt20gIZJlYDFUzcWhMp8hLP0FXuwQfvim9dLuXlrplnFjfa8qWHpiyi6v5gYVAOJ9cpzRUankNTiRN3G2nFUtjWQlzVV7BHlOB00tXJba96fnj8VXssUxB8jttGXkrjbCZ8WRJP6+sP0pYcsYbG/+Gm+rvFt1qYQiiAfMNXfx4vlSclR915NhJsi2bzueIBce5+aql9uQYy571pM+dFcACv4r7tHebtMDkErRB8DCovndGvHg==
X-Exchange-Antispam-Report-Test: UriScan:;
X-Exchange-Antispam-Report-CFA-Test: BCL:4;PCL:0;RULEID:(701105)(2401047)(8121501046)(1430428)(1431068)(1432130)(1551054)(9101536074)(3231254)(901025)(902075)(913088)(7045084)(944501410)(52103095)(52105095)(52106170)(52401190)(52505095)(52406095)(52305095)(52206095)(93006095)(93005095)(10201501046)(3002001)(1610001)(9300000083)(9301000104)(8301001075)(8301003183)(201708071742011)(7699016);SRVR:MMXP123MB1087;BCL:4;PCL:0;RULEID:;SRVR:MMXP123MB1087;
X-MS-Exchange-Organization-SCL: 1
X-Microsoft-Exchange-Diagnostics: =?us-ascii?Q?1;MMXP123MB1087;23:OYFL2HEe/wMehseiVrWl0BepT3hgC1B29HRIlquLK?=
 =?us-ascii?Q?d4bKATa8XdYKx3eOP7y9S6iWEdexUA3lXIXP+GP8+vK00nHkFPtUTu8YOHy6?=
 =?us-ascii?Q?stxObBCqvyZR8EJUekkSvCyNMfH1noGy2JcLzS3sKkEO2e7DMNaU6WJiotF+?=
 =?us-ascii?Q?6CDXGd4hkjJeVLusTSAPGqydf6TzqKpoZYk0z5xEa9nObl2BhDz6wIveCiUy?=
 =?us-ascii?Q?OvMUKPFHMkWg7pbNEHFOd6nv1t3jXl6ZnKeDERjh9o5OvP4z2eYT/NvkzUTf?=
 =?us-ascii?Q?JbdKZQBR+3f0xdB398H7WOcVjfHKOZV2FNRH7wBH2nV/9P/OO7k2lp6UT0JI?=
 =?us-ascii?Q?SuxL/wwMPM40Pp5y4OO2VZkoNQ21McNZnPmV83XfHxmpqDcekq9OFTJdzHVD?=
 =?us-ascii?Q?+FR56IGkLWJb93/VQMkFzvXKCgfPZCbHiVWf1curhA8zWldMRHTIeRI7EOtK?=
 =?us-ascii?Q?LSJTutmzgl1E4ZLvPvtnrWMlgG6B1rc+5Vnfyr6uhwJZCtThgq+nW+9VBg2u?=
 =?us-ascii?Q?+VUK2rJJQdSJzD+0KVfqx1Rv1ch+TZZCvBYcgPiUbHEvV/DiZenKnrWUY8g3?=
 =?us-ascii?Q?SHnbwT0edLf/cVz3/6PCSi+gxrAmrJyQEO+bdvr03JXObgi/2DZr8eoGDBBM?=
 =?us-ascii?Q?86t/E8zUtukHmn/OlbXbV2nX1deHi90i8qNjFzGlJB/Spz8LpzprEgiVAoPd?=
 =?us-ascii?Q?92AZhZEp8ySaIg5h78AulMg/5KxzG89lhD/kwdbJL5U4RBFyaWeKHdyCRxO4?=
 =?us-ascii?Q?Q4nL1w1o0rpCAR32BgsvuR2BnHpM7iRudvHG8IMXB5uo3qivpX3A7lvWV9SR?=
 =?us-ascii?Q?a1wtZXqvjp0aMtuWDNGmB9hZOILYvrfsqrqvyOaQycJX8vWTYKS6v6yAzdCR?=
 =?us-ascii?Q?JsiV2OfDum5gp8gOVxlsHtO8ps3eLEs8K8dQzTLQKSjOLO9n73SB/iM83p37?=
 =?us-ascii?Q?aOrV3PkLyrCRK3cDXgSkrvryIWDFFxJ6wNS0GTsW1mx55EE0E3QDAu88MtIl?=
 =?us-ascii?Q?eDOkuToFU5PzM9ZZrhys93pyoahuL2havIKOey3IEPmNA=3D=3D?=
X-Microsoft-Exchange-Diagnostics: 1;MMXP123MB1087;6:zRm1tp8beQCVJ72mNaLpVOgoBLyCtciGYsr+Oh123XrwK0gIntNfz23+e4sGsoo+M8dzI7YTaAXx2UPjLuUjw5kuYUEFxvMuJLZ3FmVQbxa2b5nqVYdt2Sl++FCac+GDV6BDsZ1hc+AzAFMnIwViYobE21zDNS6BY8u0LJ4Lq+aiuTxNeep0daSd7beUAQpNKRNgQno/YuZ+86wSxjRw7NlmiNA/HVVnrN2D/NPy5tMZLwEN/ofyW/pCbFcyfwhDkDdwRxHV+vsxssOO9x3DHCknCwIyCJD4dVDxXAeHSvDByae40M6hNBOmb/mL4nYcFcr+VLHaFgRGHDqVhZQs/AkfjQcbMqyLPwtwg4CNczQ3g64DtYbuJopbBAB5mqOHWqukkOt5mFUMPqltZAqzTGJ+/RChzLge9Qh7qZzsl1k9nN7GX+T0Z6sOgbls3jCcGkDF74bWrGd3DuFsuq0BFQ==;5:BDdYo4l9yhSam79vMjKgVsPJNwRTxNMaCYPEgmlLDFPrKVklJINB+T7wW2n+BQetPpGBkdy2rQr8xgCziwkriDT76pfY/zPzqiSJEyXqutgl+NORSbg5Kde+VXCT9qE0R4BE2Br6WbbvYUF74451gjaUdBOdkyi74Pv0cAt4J68=;24:/G/zQZjKJS/bDRjiHQVvm/DSSg6P7wkcBBVuiXCzV5mzc4Fb29ogdnK7XXI7nNjL3AEpkdxett1orNQufCuBbAJpqGMs3H5zB+hDUNAbcKg=
SpamDiagnosticOutput: 1:5
SpamDiagnosticMetadata: :4
X-Microsoft-Exchange-Diagnostics: 1;MMXP123MB1087;7:SbAr7dpbt34Dqa3ocpo09ygZcj8wOxg4WLsVqGO9xtZFNyVWh5ErIdeC2+HxgKPMAT+8Hf70kvwrjV5HcvHVjvgtOIpb4FhCq01qHSFwEtQO0fBngFVCTEqPk1P4grmvCwao1MbxPgwO4EWTiD+7DNc9YFpwoIlHGlplh8QbjTZGb45lIGGRuHCpu3qljL2C6ESdLt4/G9eaQwEAo8Hl3U9HxVyLysozBE+7Umo+9kfi5AKHbeIiIbz27uAstXcT
X-MS-Office365-Filtering-Correlation-Id: 48a72bd9-2e36-4726-a581-08d5c0031edd
X-MS-Exchange-CrossTenant-OriginalArrivalTime: 22 May 2018 16:43:17.3226
 (UTC)
X-MS-Exchange-CrossTenant-Network-Message-Id: 48a72bd9-2e36-4726-a581-08d5c0031edd
X-MS-Exchange-CrossTenant-Id: f9cd9cab-0fbe-499e-afa8-70c6c5d6219f
X-MS-Exchange-CrossTenant-FromEntityHeader: Internet
X-MS-Exchange-Transport-CrossTenantHeadersStamped: MMXP123MB1087
X-MS-Exchange-Transport-EndToEndLatency: 00:00:02.8837801
X-MS-Exchange-Processed-By-BccFoldering: 15.20.0776.003
X-Microsoft-Exchange-Diagnostics:
	1;LOXP123MB1077;9:3C7YKBQSAXlJu92VZLBA4DPjuQW7QDMqF2TrYGvlSThAtkOnwqB5PrKgbptKIfanISB0aEcNMgiJAh1nym8OzujggoeDEKhTurM/+gnfQ79r7bmw13hpm7u+ftQiSxf/
X-Microsoft-Antispam-Message-Info:
	L+PRkQe9p/dMMKpfqd3zXJHnQtvEdQIY7LWl1wAmrq/Q4EOy0AmPgzccAdva+v9PzqQ2nRbYBnwAeh3tNcdUem+gUOIqbpLskDrTY3iXSILDXYIdTPvmwcwqVe0Elf7kfYfLtBICBR2JdgpDbtmDv0wZspsQZ2CqIkkKSi/9Lzg0LgexCKkV39eG1degfR4x7l3vt6D5sSWwNSipSuMi68fzEVz/UpEDuIF5HlX4TFHoeJQmyMES0SYikj6J/gxFAbbKTo8nEBEOtRrpXEClt+6u9SSQqEp2VaunjHpSbQXWqgFueszF6SDjdNVmmab77QF+cPacXok/FhWUylJ986hJWYsI5LIM3NSnxrF2eQok4cN1HwGPSf7ySlWbWbPrZ0r5yLj43gpaT30zuCiCV17d7dxGmjHh1023eDQGlnNAROFriwfmtmKPCS+YGI5/TfghhaOcqSuEdMkpNWStIcgYuyG9XWC3Bwc1HsGM6ZU=
X-Microsoft-Exchange-Diagnostics:
	1;LOXP123MB1077;27:vCSGhU1B91D8YMowz2LZwsTFCz//dyLVRg8oNT5+bAKDf/+WI8H9quyXu8tnTIMUEvm6oZXizulbSvrFY1BiZAIU9uUC02d3MeS8zqO9tN6f1mO51k6zUP6guutuymxX
Content-type: multipart/alternative;
	boundary="B_3609856863_1566388826"

> This message is in MIME format. Since your mail reader does not understand
this format, some or all of this message may not be legible.

--B_3609856863_1566388826
Content-type: text/plain;
	charset="UTF-8"
Content-transfer-encoding: 7bit

Hi Jakub,

Gggg Gghhg has arrived and is in the guest reception area.

Have a great day!
Powered by Welkio


--B_3609856863_1566388826
Content-type: text/html;
	charset="UTF-8"
Content-transfer-encoding: quoted-printable

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org=
/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns=3D"http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv=3D"Content-Type" content=3D"text/html; charset=3Dutf-8">
<meta name=3D"viewport" content=3D"width=3Ddevice-width, initial-scale=3D1.0">
<title></title>
<style type=3D"text/css">
            #outlook a {padding: 0;}
            body {width: 100% !important; max-width: 100% !important; margi=
n:0; padding:0; background-color: #fafafa; color: #333; font-family: "Helvet=
ica Neue", Helvetica, Arial, sans-serif; font-size: 16px; -webkit-text-size-=
adjust:100%; -ms-text-size-adjust:100%;}
            .ExternalClass {width: 100%;}
            .ExternalClass, .ExternalClass p, .ExternalClass span, .Externa=
lClass font, .ExternalClass td, .ExternalClass div {line-height: 100%;}
            #backgroundTable {width: 100% !important; max-width: 100% !impo=
rtant; margin: 30px 0 0; padding:0; background-color: #fafafa; color: #333; =
font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; font-size: 16px=
; line-height: 140% !important;}
            table td {border-collapse: collapse;}
            a         {color: #080808; text-decoration: none;}
            a:link    {color: #080808; text-decoration: none;}
            a:visited {color: #080808; text-decoration: none;}
            a:focus=C2=A0=C2=A0 {color: #080808; text-decoration: none;}
            a:hover=C2=A0=C2=A0 {color: #080808; text-decoration: none;}
            #footer a         {color: #999; text-decoration: none;}
            #footer a:link    {color: #999; text-decoration: none;}
            #footer a:visited {color: #999; text-decoration: none;}
            #footer a:focus=C2=A0=C2=A0 {color: #999; text-decoration: none;}
            #footer a:hover=C2=A0=C2=A0 {color: #999; text-decoration: none;}
            p {margin: 0 0 22.4px 0; padding: 0;}
            p:last-child {margin-bottom: 0;}
        </style>
</head>
<body style=3D"width: 100%; max-width: 100%; margin: 0; padding:0; background=
-color: #fafafa; color: #333; font-family: 'Helvetica Neue', Helvetica, Aria=
l, sans-serif; font-size: 16px; -webkit-text-size-adjust: 100%; -ms-text-siz=
e-adjust: 100%;">
<table width=3D"100%" cellpadding=3D"0" cellspacing=3D"0" border=3D"0" align=3D"cente=
r" id=3D"backgroundTable" style=3D"width: 100%; max-width: 100%; margin:0; paddi=
ng:0; background-color: #fafafa; color: #333; font-family: 'Helvetica Neue',=
 Helvetica, Arial, sans-serif; font-size: 16px; line-height: 140%; border-co=
llapse: collapse; mso-table-lspace: 0pt; mso-table-rspace: 0pt; -webkit-text=
-size-adjust: 100%; -ms-text-size-adjust: 100%;">
<tbody>
<tr>
<td width=3D"100%" valign=3D"top" style=3D"padding-right: 12px; padding-left: 12p=
x;">
<div style=3D"max-width: 600px; margin-left: auto; margin-right: auto; paddin=
g: 0">
<table width=3D"100%" cellpadding=3D"0" cellspacing=3D"0" border=3D"0" align=3D"cente=
r" style=3D"background-color: #fff; border-collapse: collapse; mso-table-lspac=
e: 0pt; mso-table-rspace: 0pt;">
<tbody>
<tr>
<td width=3D"100%" style=3D"background-color: #fafafa; height: 28px;"></td>
</tr>
<tr>
<td width=3D"100%" align=3D"center" valign=3D"middle" style=3D"height: 120px; text-=
align: center;">
<a href=3D"#" style=3D"text-decoration: none;"><img src=3D"https://media.welkio.c=
om/images/logos/t-logo-sm/97c5473aacaa43bfa955c00b5a14a9e454b161784a0e48c2ba=
4344dc9e0e9472.png" border=3D"0" alt=3D"WeWork" style=3D"display: block; margin-le=
ft: auto; margin-right: auto; outline: none; border: none; max-width: 150px;=
 max-height: 50px; margin-bottom: -3px; -ms-interpolation-mode: bicubic;"></=
a>
</td>
</tr>
<tr>
<td width=3D"100%" valign=3D"top" style=3D"padding-right: 34px; padding-bottom: 4=
4px; padding-left: 34px; background-color: #fff;">
<table width=3D"100%" cellpadding=3D"0" cellspacing=3D"0" border=3D"0">
<tbody>
<tr>
<td width=3D"100%" align=3D"center" valign=3D"top" style=3D"padding-bottom: 20px; t=
ext-align: center;">
<img src=3D"https://media.welkio.com/images/visitors/t-avatar-md/7ff7408dd666=
49c08bfc723770de0e0c41fedb07e40941ac84d55c6d98beaf57.png" alt=3D"Visitor photo=
" width=3D"120" height=3D"120" style=3D"display: block; margin-left: auto; margin-=
right: auto; outline: none; border: 1px solid #eeeeee; border-radius: 60px; =
-ms-interpolation-mode: bicubic;">
</td>
</tr>
<tr>
<td width=3D"100%" valign=3D"top">Hi Jakub, <br>
<br>
Gggg Gghhg has arrived and is in the guest reception area.<br>
<br>
Have a great day! </td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td width=3D"100%" style=3D"background-color: #080808; height: 20px;"></td>
</tr>
<tr>
<td width=3D"100%" align=3D"center" valign=3D"middle" id=3D"footer" style=3D"padding-=
top: 16px; padding-right: 12px; padding-bottom: 16px; padding-left: 12px; ba=
ckground-color: #fafafa; color: #beb9b9; font-size: 13px; line-height: 150%;=
 text-align: center;">
<a href=3D"https://welkio.com" style=3D"color: #beb9b9; text-decoration: none;"=
>Powered by
<strong>Welkio</strong></a> </td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
</body>
</html>


--B_3609856863_1566388826--

`;

	 const [ , visitorPhotoUrlRaw ] = testingUrl.match(/"(https:\/\/.+\.welkio\.com\/[\S\n\r]+)/i) || [];
	 const visitorPhotoUrl = (visitorPhotoUrlRaw || ``).replace(/=\n/g, ``);

app.post('/email', async (req, res) => {

console.log('I work. email');
const nameVisitor = (req.body.Subject.match(/guest:([^.]+)/i)[1]);
console.log(nameVisitor);

	const deliveryType = req.body['Subject'].match(/package/i) ? 'package' : 'letter';

	// if (req.body['From'].match(/moorgate@wework\.com$/i)) {
	// const testingUrl = `https://media.welkio.com/images/visitors/t-avatar-md/7ff7408dd666=
	// 49c08bfc723770de0e0c41fedb07e40941ac84d55c6d98beaf57.png`;
	//
	// 	 const [ , visitorPhotoUrlRaw ] = testingUrl.match(/"(https:\/\/.+\.welkio\.com\/[\S\n\r]+)/i) || [];
	// 	 const visitorPhotoUrl = (visitorPhotoUrlRaw || ``).replace(/=\n/g, ``);

		const content = `Visitor *${nameVisitor}* has arrived to see ${req.body.ToFull[0].Name}. Just look at this ugly mug`;


		await pushToSlack('https://hooks.slack.com/services/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', deliveryType, content, visitorPhotoUrl);

	// } else if (req.body['From'].match(/@wework\.com$/i)) {
	// 		const content = `There is a *${delType}* waiting in the mailroom :love_letter:`;
	// 	await pushToSlack('https://hooks.slack.com/services/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', deliveryType, content);
	// 	res.send('I work too');
	// }
	return res.send('ok');



});


/*
*    regex for 3D images decoding so we can extract the visitor image
*/
//
// const [ , visitorPhotoUrlRaw ] = htmlBody.match(/"(https:\/\/.+\.welkio\.com\/[\S\n\r]+)/i) || [];
// const visitorPhotoUrl = (visitorPhotoUrlRaw || ``).replace(/=\n/g, ``);
// }
