**To delete a network ACL**

This example deletes the specified network ACL. If the command succeeds, no output is returned.

Command::

  aws ec2 delete-network-acl --network-acl-id acl-5fb85d36
